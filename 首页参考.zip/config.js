
export default {
	server: "http://192.168.0.15:666",
	appName: "云同城",
	
	
	// #ifdef APP-PLUS
	version: plus.runtime.version,
	varsionCode: plus.runtime.versionCode,
	// #endif
	// #ifndef APP-PLUS
	version: '1.0.0',
	// #endif
	author: "吃酸菜的鱼",
	company: "汇贤网络技术有限公司",
	companyEN: "HuiXian"
}

